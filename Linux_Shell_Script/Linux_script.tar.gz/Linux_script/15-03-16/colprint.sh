#!/bin/bash

var=`cat numbers.txt`

for i in $var; do
	echo $i
done
