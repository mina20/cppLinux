#!/bin/sh

#this is the first script

for a in 01 02 03 04 05 06 07 08 09 `seq 10 15`; do 
	echo Creating a directory named CMS15$a
	mkdir CMS15$a 
	echo CMS15$a > CMS15$a/CMS15$a.txt:wq
 
done

echo "All done!"

