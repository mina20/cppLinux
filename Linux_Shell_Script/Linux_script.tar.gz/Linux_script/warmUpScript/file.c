#include<stdio.h>

int main() {
	printf("Hel lo\n Wo rld !\n blah blah blah \n blep\n");
return 0;
}
