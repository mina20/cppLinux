#!/bin/bash

var="Vaibhav"
while [ $var != "exit" ]; do
	echo "Keep Typing"
	read var
done
