factorial <- function(n)
{
    return(prod(1:n)) 

}