
#include "Complex.h"

using namespace std;

//default constructor*/
Complex::Complex()
{ real_ = imag_ = 0.0;
}

//Normal constructor
Complex::Complex(const double x, const double y)
:real_(x), imag_(y)
{
}

//copy constructor
Complex::Complex(const Complex& c)
:real_(c.getReal()), imag_(c.getImag())
{
}

void Complex::conjugate()
{real_ = real_;
  imag_=-imag_;
}

double Complex::magnitude()
{
return sqrt(real_*real_+imag_*imag_);
}

double Complex::phase()
{ return atan(imag_/real_);
}

double Complex::getReal() const
{ return real_;
}


double Complex::getImag() const
{ return imag_;
}
Complex& Complex::operator=( const Complex c)
{
this->real_ = c.getReal();
this->imag_ = c.getImag();
return (*this);
}


void Complex::set(const double x, const double y)
{
real_ = x;
imag_ = y;
}


Complex Complex::operator+(Complex& c) const
{ Complex t;
Complex c1 = c;
t.set( (real_ + c1.getReal()), (imag_ + c1.getImag()) );
return t;
}

Complex Complex::operator-(Complex& c) const
{ Complex t;
Complex c1 = c;
t.set( (real_ - c1.getReal()), (imag_ - c1.getImag()) );
return t;
}


Complex Complex::operator*(Complex& c) const
{ Complex t;
Complex c1 = c;
double x = (real_ * c1.getReal()) - (imag_ * c1.getImag());
double y = (real_ * c1.getImag()) + (imag_ * c1.getReal());
t.set(x, y);
return t;
}

Complex Complex::operator/(Complex& c) const
{ Complex t;
Complex c1=c;
double x = ((real_ * c1.getReal()) + (imag_ * c1.getImag()))/pow(c1.magnitude(),2);
double y = ((real_ * c1.getImag()) - (imag_ * c1.getReal()))/pow(c1.magnitude(),2);
t.set(x, y);
return t;
}


std::ostream& operator<<(std::ostream& os, Complex& c)
{
Complex c1 = c;
os<< "("<< c1.getReal() << "," << c1.getImag() << ")" << endl;
return os;
}

std::istream& operator>>(std::istream& is, Complex& c)
{
  double a,b;
  is>>a>>b;
  c.set(a,b);
  return (is);
}

int main ()
{
Complex x(1.0,1.0);
Complex y(2.0,0.5);

x.conjugate();
cout<<"Conjugate of x:"<<x<<endl;
cout<<"Magnitude of x:"<<x.magnitude()<<endl;
cout <<"Phase of x:"<<x.phase()<<"radians"<<endl;

Complex z1;
z1=x+y;
cout<<x<<"+"<<y<<"="<<z1<<endl;

Complex z2;
z2= x-y;
cout<<x<<"-"<<y<<"="<<z2<<endl;

Complex z3;
z3= x*y;
cout<<x<<"*"<<y<<"="<<z3<<endl;

Complex z4;
z4= x/y;
cout<<x<<"/"<<y<<"="<<z4<<endl;


return 0;
}

