//sameena-cms1329

#include"queen_header.h"

int main()
{

Queen b;
cout<<"\nSolution for the 8 Queen Problem:\n"<<endl;
b.solveQueen();
cout<<"\n";

return 0;

}

