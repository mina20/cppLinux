
#include<iostream>
using namespace std;

 class Qroot
  {
    private :
    float a,b,c;
    float x,y;
    public :
    float del();
    float root1();
    float root2();
    void getdata();
    void putdata();
    void display();


  };
	
