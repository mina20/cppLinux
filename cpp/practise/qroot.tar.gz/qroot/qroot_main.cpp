
#include"qroot_header.h"

using namespace std;

  int main()
  {
    Qroot q1;
    q1.getdata();
    q1.putdata();
    
    q1.root1();
    q1.root2();
    q1.display();
    return 0;
  }
