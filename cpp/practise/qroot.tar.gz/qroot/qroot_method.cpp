#include<iostream>
#include"qroot_header.h"
using namespace std;
  void Qroot::getdata()
 {
    cout<<"Enter values of coeffients"<<;
    cin>>a>>b>>c>>endl;
 }

 void Qroot::putdata()
 {
   cout<<"Coeffietents are"<<a<<b<<"and"<<c;
 }
  float Qroot::del()
  {
     del=sqrt(b*b-4*a*c);
  }
  float Qroot::root1()
 {
   root1= (-b+del())/2*a;
 }

  float Qroot::root2()
  {
     root2= (-b-del())/2*a;
  }
   void Qroot::display()
   {
     cout<<"real Roots are"<<root1<<root2;
   }





  








